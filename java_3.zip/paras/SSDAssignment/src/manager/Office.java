package manager;

public class Office extends Property implements SecuredAccess {

	/**
	 * The stored security code.
	 */
	private String storedCode = "1234"; // office code is 1234 as default

	/**
	 * The number of incorrect code input attempts.
	 */
	private int incorrectAttempts;

	//////////////////////////////////////////////////////
	
	@Override
	public void setCode(String code) {
		// sets stored code as the given code
		storedCode = code; 
	}

	@Override
	public boolean checkCode(String code) {
		if (isLockedOut() || !code.equals(storedCode)) {
			incorrectAttempts++; // Increases incorrect attempts if code doesnt match or room is locked out
			return false;
		}
		
		// not locked, and codes match
		
		incorrectAttempts = 0;
		return true;
	}

	@Override
	public void resetToDefault() {
		incorrectAttempts = 0; // sets incorrect attempts to default
		storedCode = "1234"; // sets code to default
	}

	@Override
	public boolean isLockedOut() {
		if (incorrectAttempts > 5)
			return true; // if incorrect attempts exceeds 5, returns true
		else
			return false; // else returns false
	}

	@Override
	public int getIncorrectAttempts() {
		return incorrectAttempts;
	}
	
	//////////////////////////////////////////////////////

	public Office(String address) {

		super(address);
	}

	
}
