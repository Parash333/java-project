package manager;

/**
 * Represents a Room within a {@link Hotel}.
 * 
 * @author Paras Subedi
 *
 */
public class Room implements SecuredAccess {

	/**
	 * The room number within the hotel.
	 */
	private int roomNum;

	/**
	 * The stored security code.
	 */
	private String storedCode = "9999"; // 9999 is default room code
	
	/**
	 * The current occupant of the room, null if the room is not occupied.
	 */
	private Guest occupant;
	
	////////////////////////////////
	
	@Override
	public void setCode(String code) {
		// sets stored code as the given code
		storedCode = code; 
	}

	@Override
	public boolean checkCode(String code) {
		if (code == storedCode) {
			return true; // Return true if code is same as storedCode
		}
		else 
			return false;
	}
	
	@Override
	public void resetToDefault() {
		storedCode = "9999"; // reset code to default
	}

	@Override
	public boolean isLockedOut() {
		return false;
	}

	@Override
	public int getIncorrectAttempts() {
		return 0;
	}
	
	/**
	 * @return the roomNum
	 */
	public int getRoomNum() {
		return roomNum;
	}

	/**
	 * @param roomNum the roomNum to set
	 */
	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}

	/**
	 * Sets the occupant of the room.
	 * 
	 * @param guest the guest which is to occupy the room
	 */
	public void setOccupant(Guest guest) {
		this.occupant = guest;
	}
	
	/**
	 * Removes any occupant from the room.
	 */
	public void removeOccupant() {
		this.occupant = null;
	}
	
	/**
	 * 
	 * @return true if the room has an occupant
	 */
	public boolean hasOccupant() {
		if (this.occupant == null) 
		return false; // if no occupant return false
		else
			return true;
	}
	
	////////////////////////////////
	
	/**
	 * Constructor.
	 * 
	 * @param roomNum the room number
	 */
	public Room(int roomNum) {
       this.roomNum = roomNum;
	}


}
