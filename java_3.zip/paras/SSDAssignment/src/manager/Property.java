package manager;

/**
 * An abstract class that represents all types of properties.
 * 
 * @author Paras Subedi
 *
 */
abstract class Property {

	/**
	 * The property address.
	 */
	private String address;
	
	/**
	 * The tenant of the property, null if the property has no tenant.
	 */
	private Tenant tenant;
	
	////////////////////////////////////
	
	/**
	 * 
	 * @return the property address.
	 */
	public String getAddress() {
		return address;
	}
	
	/**
	 * Sets the tenant of the property.
	 * 
	 * @param tenant the tenant of the property
	 */
	public void setTenant(Tenant tenant) {
		this.tenant = tenant; // sets tenant attribute to the given tenant
	}
	
	/**
	 * Removes any tenant from the property.
	 */
	public void removeTenant() {
		this.tenant = null; // sets tenant to null
	}
	
	/**
	 * 
	 * @return true if the property has a tenant
	 */
	public boolean hasTenant() {
		if (this.tenant != null) {
			return true; // Return true if tenant is not null
		}
		else
			return false;
	}
	
	/**
	 * Constructor
	 * 
	 * @param address the property address.
	 */
	Property(String address) {
		
		this.address = address;
	}
	
}
