package com.assignment.part2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

// MainPanel class that inherits(extends) from the JPanel class:
public class CurrencyPanel extends JPanel {

    // Declaring and initializing the object of the currency class:
    Currency currency = new Currency();

    // Declaring and initializing a properties of primitive data types:
    private String [] startingCurrencies = currency.getCurrencies();
    private String [] startingSymbols = currency.getSymbols();
    private double [] startingFactors = currency.getFactors();
    private double [] newFactors = new double [8];
    private String [] newSymbols = new String [8];
    private String symbolForResult;
    private boolean usingCurrencyFromFile = false;
    private int conversionCount = 0;
    // Symbols array with symbols to test against invalid symbols:
    String [] testSymbols = {"¥", "€", "$", "A$", "C$", "₩", "฿", "د.إ", "kr", "R"};

    // Creating the Swing components class type and int properties:
    private JTextField userInputTextField;
    private JLabel conversionResult;
    private JLabel numberOfConversionLabel;
    private JLabel inputLabel;
    private JCheckBox reverseCheckBox;
    private JButton resetButton;
    private JButton convertButton;
    private JButton uploadFileButton;
    private JComboBox<String> currencyComboBox;

    // Constructor of MainPanel class
    CurrencyPanel(){
        // Creating and initializing a local object of the JLabel class:
        inputLabel = new JLabel("Enter value:");

        // Initializing the objects of the Swing components:
        userInputTextField = new JTextField(5);
        conversionResult = new JLabel("---");
        numberOfConversionLabel = new JLabel("Conversion count: 0");
        reverseCheckBox = new JCheckBox("Reverse conversion", false);
        reverseCheckBox.setBackground(new Color(0x4663AC));
        resetButton = new JButton("Reset");
        convertButton = new JButton("Convert");
        uploadFileButton = new JButton("Upload File");
        currencyComboBox = new JComboBox<String>(startingCurrencies);

        // Creating the objects of the inner classes:
        ActionListener conversionListener = new ConvertButtonListener();
        ActionListener resetButtonListener = new ResetButtonListener();
        ActionListener loadMenuItemListener = new LoadMenuItemListener();

        // Calling the addActionListener() methods using the Swing component objects:
        convertButton.addActionListener(conversionListener);
        userInputTextField.addActionListener(conversionListener);
        reverseCheckBox.addActionListener(conversionListener);
        resetButton.addActionListener(resetButtonListener);
        uploadFileButton.addActionListener(loadMenuItemListener);
        
        // Setting the tool tips of the components:
        currencyComboBox.setToolTipText("A drop down list of currencies that you can convert to or from.");
        inputLabel.setToolTipText("Label with instructions.");
        userInputTextField.setToolTipText("Type inside of this TextField to get the conversions you want.");
        convertButton.setToolTipText("Click to convert the value that you have inputted.");
        conversionResult.setToolTipText("The conversion results.");
        numberOfConversionLabel.setToolTipText("The number of conversions that have been converted.");
        uploadFileButton.setToolTipText("Click to upload a currency file from your local computer.");
        reverseCheckBox.setToolTipText("Click to reverse the conversion from the selected currency to british pounds.");
        resetButton.setToolTipText("Click to reset the TextField and the conversion counts.");

        // Using the GridLayout manager for our main panel. Setting an empty border to create space between the
        // JPanel and the JFrame. Setting the horizontal and vertical gaps between the components in the GridLayout.
        GridLayout gridLayout = new GridLayout(3, 3);
        setBorder(BorderFactory.createEmptyBorder(10, 55, 10, 20));
        gridLayout.setVgap(15);
        gridLayout.setHgap(20);
        setLayout(gridLayout);

        // Creating sub panels (subPanel1 and subPanel2) which groups together 2 components each. I have used
        // BoxLayout manager for the sub panels so that the components take up all of the X axis space in the
        // sub panels.
        JPanel subPanel1 = new JPanel();
        subPanel1.setLayout(new BoxLayout(subPanel1, BoxLayout.X_AXIS));
        subPanel1.add(inputLabel);
        // Creating an invisible component so there is space between the 2 components:
        subPanel1.add(Box.createRigidArea(new Dimension(10, 0)));
        subPanel1.add(userInputTextField);
        subPanel1.setBackground(new Color(0x4663AC));
        JPanel subPanel2 = new JPanel();
        subPanel2.setLayout(new BoxLayout(subPanel2, BoxLayout.X_AXIS));
        subPanel2.add(convertButton);
        // Creating an invisible component so there is space between the 2 components:
        subPanel2.add(Box.createRigidArea(new Dimension(10, 0)));
        subPanel2.add(conversionResult);
        subPanel2.setBackground(new Color(0x4663AC));

        // Creating 2 empty sub panels(subPanel3, subPanel4) to take up spaces in the grid so that
        // the reset button is on the grid cell on row 3, column 2.
        JPanel subPanel3 = new JPanel();
        JPanel subPanel4 = new JPanel();
        subPanel3.setBackground(new Color(0x4663AC));
        subPanel4.setBackground(new Color(0x4663AC));

        // Adding the Swing components and sub panels to the Main panel:
        add(currencyComboBox);
        add(subPanel1);
        add(subPanel2);
        add(uploadFileButton);
        add(reverseCheckBox);
        add(numberOfConversionLabel);
        add(subPanel3);
        add(resetButton);
        add(subPanel4);

        // Setting the preferred size and color for the JPanel:
        setPreferredSize(new Dimension(700, 120));
        setBackground(new Color(0x4663AC));
    }

    // Creating a JMenuBar type method that returns a JMenuBar object:
    JMenuBar setUpMenu() {

        // Creating the object of the JMenuBar class:
        JMenuBar menuBar = new JMenuBar();

        // Creating objects of JMenu class:
        JMenu helpMenu = new JMenu("Help");
        JMenu fileMenu = new JMenu("File");

        // Setting the tool tip text of the JMenu objects:
        helpMenu.setToolTipText("Click to view the help options for this application.");
        fileMenu.setToolTipText("Click to view the file options for this application.");

        // Creating the objects of the JMenuItem class:
        JMenuItem aboutMenuItem = new JMenuItem("About");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        JMenuItem loadMenuItem = new JMenuItem("Load");

        // Setting the tool tip text of the JMenuItem objects:
        aboutMenuItem.setToolTipText("Click to get more information about how this Currency Conversion application works.");
        exitMenuItem.setToolTipText("Click to exit the application.");
        loadMenuItem.setToolTipText("Click to load currencies from a text file from your local computer.");

        // Adding the JMenuItems (aboutItem and exitItem) to the JMenu Objects (helpMenu and fileMenu):
        fileMenu.add(exitMenuItem);
        fileMenu.add(loadMenuItem);
        helpMenu.add(aboutMenuItem);

        // Adding JMenu objects(helpMenu and fileMenu) to the JMenuBar:
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);

        // Setting keyboard shortcuts for the exit and about menu items:
        // Hold down alt(option for mac) and e to close application.
        // Hold down alt(option for mac) and a to get the about dialogue box to pop out:
        // Hold down alt(option for mac) and l to load a text file of currencies from a local computer:
        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.ALT_MASK));
        exitMenuItem.setMnemonic(KeyEvent.VK_E);
        aboutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK));
        aboutMenuItem.setMnemonic(KeyEvent.VK_A);
        loadMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.ALT_MASK));
        loadMenuItem.setMnemonic(KeyEvent.VK_L);

        // Creating the ImageIcon class's objects and adding them to the JMenu and JMenuItem objects:
        ImageIcon fileImageIcon = new ImageIcon("src/images/file.png");
        ImageIcon helpImageIcon = new ImageIcon("src/images/help.png");
        ImageIcon exitImageIcon = new ImageIcon("src/images/exit.png");
        ImageIcon aboutImageIcon = new ImageIcon("src/images/about.png");
        ImageIcon loadImageIcon = new ImageIcon(
                new ImageIcon("src/images/load.png")
                .getImage()
                .getScaledInstance(24, 24, Image.SCALE_DEFAULT)
        ); // Resizing an image to make it smaller than it's original size.
        fileMenu.setIcon(fileImageIcon);
        helpMenu.setIcon(helpImageIcon);
        exitMenuItem.setIcon(exitImageIcon);
        aboutMenuItem.setIcon(aboutImageIcon);
        loadMenuItem.setIcon(loadImageIcon);

        // Creating the inner classes' objects which implements the ActionListener interface
        // to pass to the actionListener() method:
        ActionListener exitListener = new ExitMenuItemListener();
        ActionListener aboutListener = new AboutMenuItemListener();
        ActionListener loadListener = new LoadMenuItemListener();
        exitMenuItem.addActionListener(exitListener);
        aboutMenuItem.addActionListener(aboutListener);
        loadMenuItem.addActionListener(loadListener);

        // Returning the object of the JMenuBar class:
        return menuBar;
    }

    // A method that clears the JTextField and JLabals:
    private void clearValues(){
        userInputTextField.setText("");
        conversionResult.setText("---");
        conversionCount = 0;
        numberOfConversionLabel.setText("Conversion count: " + conversionCount);
    }

    // Method to load the currencies from the file:
    void loadCurrencyFile(File userSelectedFile) {

        // Using try catch block because InputStreamReader throws "java.io.UnsupportedEncodingException" exception
        // if the named charset is not supported and FileInputStream throws "java.io.FileNotFoundException" exception
        // if file is not found.
        try {

            // Using the BufferedReader, InputStreamReader and FileInputStream to read from the text file.
            BufferedReader inputFromFile =
                    new BufferedReader(new InputStreamReader(new FileInputStream(userSelectedFile), "UTF8"));

            // Storing the first line for the text file in String variable line:
            String line = inputFromFile.readLine();

            // A counter for the arrays to use in the for loop:
            int counterForFactors = 0;
            int counterForSymbols = 0;

            // Removing the previous currencies from the JComboBox to add the new ones:
            currencyComboBox.removeAllItems();

            // Looping through the line variable which contains the lines of the text file if the line is not null:
            while ( line != null ) {

                // Process 'line' (split up) - Store the string values separated by comma in the parts String array:
                String [] parts = line.split(",");

                if (parts.length < 3) {
                    JOptionPane.showMessageDialog(null, "Invalid number of data values!\n" +
                                    "There should be 3 values(currency, currency conversion factory and currency " +
                                    "symbol) in a line of the file!",
                            "ERROR!", JOptionPane.ERROR_MESSAGE);
                    currencyComboBox.addItem("Invalid data ");
                    newFactors[counterForFactors] = 0.0;
                    newSymbols[counterForSymbols] = "Invalid";
                    counterForFactors++;
                    counterForSymbols++;
                }else {
                    // A for loop to loop through the parts array and use the elements of the array:
                    for(int i = 0; i < parts.length; i++){
                        if (i == 0) {
                            // Adding the new currencies to the JComboBox:
                            currencyComboBox.addItem(parts[i].trim());
                        }else if (i == 1){
                            // Storing the factors from the file into the newFactors array:
                            try{
                                newFactors[counterForFactors] = Double.parseDouble(parts[i].trim());
                                counterForFactors++;
                            }catch (Exception e){
                                JOptionPane.showMessageDialog(null,
                                        "There was invalid value(Non-numerical) for the conversion factor " +
                                                "in the file.\nThe invalid value caused the parsing from a String to " +
                                                "a Double to fail!\n"
                                                + e.getMessage() + ".", "ERROR!", JOptionPane.ERROR_MESSAGE);
                                // If there is an invalid factor, removing the last added currency in the JComboBox.
                                currencyComboBox.removeItemAt(currencyComboBox.getItemCount() - 1);
                                currencyComboBox.addItem("Invalid data");
                                newFactors[counterForFactors] = 0.0;
                                newSymbols[counterForSymbols] = "Invalid";
                                counterForFactors++;
                                counterForSymbols++;

                                // Break out of the for loop if an invalid factor is caught. No point in checking for
                                // symbols.
                                break;
                            }
                        }else {

                            // Storing the new symbols from the file to the symbols array:
                            String fileSymbol = parts[i].trim();

                            // If the symbol from file is equal to any of the symbols in the testSymbols array, then
                            // we want to use the symbol from file.
                            // If an invalid symbol is found, we want to remove the currency from the JComboBox and
                            // inform the user.
                            boolean symbolDoesExist = false;
                            for(String symbol : testSymbols){
                                if (fileSymbol.equals(symbol)){
                                    newSymbols[counterForSymbols] = fileSymbol;
                                    counterForSymbols++;
                                    symbolDoesExist = true;
                                }
                            }
                            if (!symbolDoesExist){
                                JOptionPane.showMessageDialog(null, "Invalid currency " +
                                                    "symbol from the file has been found! Invalid symbol: \""
                                                + fileSymbol + "\".",
                                            "ERROR!", JOptionPane.ERROR_MESSAGE);
                                currencyComboBox.removeItemAt(currencyComboBox.getItemCount() - 1);
                                currencyComboBox.addItem("Invalid data");
                                // Override the old factor if the symbol is invalid.
                                newFactors[counterForFactors - 1] = 0.0;
                                newSymbols[counterForSymbols] = "Invalid";
                                counterForFactors++;
                                counterForSymbols++;
                            }
                        }
                    }
                }
                line = inputFromFile.readLine(); // read next line (if available)
            }
            // Closing the BufferedReader after we are done with it:
            inputFromFile.close();

        } catch (Exception e) {

            // Storing the error message in errorMessage String variable:
            String errorMessage = e.getMessage();

            // Show the message to the user through a message dialog box:
            JOptionPane.showMessageDialog(null, errorMessage,
                    "ERROR!", JOptionPane.ERROR_MESSAGE);
        }

    }

    // A method that returns a currency conversion factor for the selected index on the JComboBox
    // and changes the String symbolForResult's value:
    private double getConversionFactor(int indexPosition, boolean isChecked){

        double factor = 0;

        switch(indexPosition){
            case 0:
                factor = startingFactors[0];
                break;
            case 1:
                factor = startingFactors[1];
                break;
            case 2:
                factor = startingFactors[2];
                break;
            case 3:
                factor = startingFactors[3];
                break;
            case 4:
                factor = startingFactors[4];
                break;
            case 5:
                factor = startingFactors[5];
                break;
            case 6:
                factor = startingFactors[6];
                break;
            case 7:
                factor = startingFactors[7];
                break;
        }

        if (isChecked){
            symbolForResult = "£";
        }else {
            symbolForResult = startingSymbols[indexPosition];
        }

        return factor;
    }

    // Method to that returns new currency conversion factors from the text file and and changes
    // the String symbolForResult's value:
    private double getNewFactors(int indexPosition, boolean isChecked){

        double factor = 0;

        if (isChecked){
            symbolForResult = "£";
        }else {
            symbolForResult = newSymbols[indexPosition];
        }

        switch(indexPosition){
            case 0:
                factor = newFactors[0];
                break;
            case 1:
                factor = newFactors[1];
                break;
            case 2:
                factor = newFactors[2];
                break;
            case 3:
                factor = newFactors[3];
                break;
            case 4:
                factor = newFactors[4];
                break;
            case 5:
                factor = newFactors[5];
                break;
            case 6:
                factor = newFactors[6];
                break;
            case 7:
                factor = newFactors[7];
                break;
        }
        return factor;
    }

    // Private inner class ConvertButtonListener that implements the ActionListener interface:
    private class ConvertButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {

            // Declaring a string property text and assigning it the user inputted text trimmed of
            // leading and trailing spaces:
            String text = userInputTextField.getText().trim();

            // If the text from the TextField is not empty and reverseCheckBox checkbox is not
            // checked:
            if (!text.isEmpty() && !reverseCheckBox.isSelected()) {

                double value = 0; // Declaring and initializing a variable called value to 0:

                // If parsing fails, it is because a non number has been inputted so display
                // a dialog warning box and end the conversion:
                try{
                    value = Double.parseDouble(text.trim());  // Parsing the String we got from textField to double by trimming it.
                }catch (Exception e){
                    JOptionPane.showMessageDialog(null,
                            "You have entered an invalid number. (For example: \"Abc, &*...etc.\"). Please enter a valid number.",
                            "WARNING",
                            JOptionPane.WARNING_MESSAGE);
                    return; // Stop the conversion so that the result will not display 0.00
                }

                // If we are using the currencies from the file use the factor returned from the getNewFactors() method
                // else use the factor returned from getConversionFactor():
                double factor = usingCurrencyFromFile ? getNewFactors(currencyComboBox.getSelectedIndex(), false)
                        : getConversionFactor(currencyComboBox.getSelectedIndex(), false);
                double result; // Variable result declared to store the conversion result

                // Incrementing conversionCounter after every conversion and formatting the result
                // of the conversion as a string and setting it as the resultLabel's text and setting
                // the conversionCountLabel's text. But if the result is 0.0, then displaying
                // a dialog box to the user to inform them that we cannot perform conversions with invalid data.
                // (This only happens if the text file data is corrupted and they convert the corrupted data.)
                if (factor == 0.0) {
                    JOptionPane.showMessageDialog(null, "Conversions cannot be made with " +
                            "invalid data!", "Trying to convert an invalid data!", JOptionPane.WARNING_MESSAGE);
                    return; // Stopping this method's execution if user tried to convert invalid data.
                }else {
                    // Getting the result of the conversion:
                    result = value * factor;
                    String resultIn2dp = String.format("%.2f", result);
                    conversionResult.setText(symbolForResult + resultIn2dp);
                }
                conversionCount++;
                numberOfConversionLabel.setText("Conversion count: " + conversionCount);
            } else if (!text.isEmpty() && reverseCheckBox.isSelected()){

                // If the text from the TextField is not empty but reverseCheckBox checkbox is
                // checked:

                double value = 0; // Declaring and initializing a variable called value to 0:

                // If parsing fails, it is because a non number has been inputted so display
                // a dialog warning box and end the conversion:
                try{
                    value = Double.parseDouble(text.trim()); // Parsing the String we got from textField to double by
                    // trimming it.
                }catch (Exception e){
                    JOptionPane.showMessageDialog(null,
                            "You have entered an invalid number. (For example: \"Abc, &*...etc.\"). " +
                                    "Please enter a valid number.",
                            "WARNING",
                            JOptionPane.WARNING_MESSAGE);
                    return; // Stop the conversion so that the result will not display 0.00
                }

                // If we are using the currencies from the file use the factor returned from the getNewFactors()
                // method else use the factor returned from getConversionFactor():
                double factor = usingCurrencyFromFile ? getNewFactors(currencyComboBox.getSelectedIndex(),
                        true)
                        : getConversionFactor(currencyComboBox.getSelectedIndex(), true);
                double result; // Variable result declared to store the conversion result

                // Incrementing conversionCounter after every conversion and formatting the result
                // of the conversion as a string and setting it as the resultLabel's text and setting
                // the conversionCountLabel's text. But if the result is 0.0, then displaying
                // a dialog box to the user to inform them that we cannot perform conversions with invalid data.
                // (This only happens if the text file data is corrupted and they convert the corrupted data.)
                if (factor == 0.0) {
                    JOptionPane.showMessageDialog(null, "Conversions cannot be made with " +
                            "invalid data!", "Trying to convert an invalid data!", JOptionPane.WARNING_MESSAGE);
                    return; // Stopping this method's execution if user tried to convert invalid data.
                }else {
                    // Getting the conversion result:
                    result = value / factor;
                    String resultIn2dp = String.format("%.2f", result);
                    conversionResult.setText(symbolForResult + resultIn2dp);
                }
                conversionCount++;
                numberOfConversionLabel.setText("Conversion count: " + conversionCount);

            }else {
                // If the user input TextField is empty, display this dialog box as a warning message:
                JOptionPane.showMessageDialog(null,
                        "The TextField should not be empty. Please enter a number.",
                        "WARNING",
                        JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Private inner class ResetButtonListener that implements the ActionListener interface:
    private class ResetButtonListener implements ActionListener{

        // Clearing the TextField, result, resetting the value of conversionCounter to 0
        // and setting the conversionCountLabel's text when the user presses on the clear button:
        @Override
        public void actionPerformed(ActionEvent e) {
            clearValues(); // Calling method clearValues() that clears JTextField and JLabels.
        }
    }

    // Private inner class ExitMenuItemListener that implements the ActionListener interface:
    private class ExitMenuItemListener implements ActionListener {

        // Exiting the program when the exit menu option's item is clicked:
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }

    }

    // Private inner class AboutMenuItemListener that implements the ActionListener interface:
    private class AboutMenuItemListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            // Displaying a dialog box with informational message when the about JMenuItem is clicked:
            JOptionPane.showMessageDialog(null,
                    "Currency Converter - An application that converts the value in British Pounds " +
                            "inputted by the user to one of \ncurrencies selected by the user in the JComboBox drop " +
                            "down list. \nThis application also converts the currency in reverse from the selected " +
                            "currency back to British Pounds when the JCheckBox is\nselected.\nAdditionally, it also " +
                            "notes down the number of times you have used this app to make a currency conversion. " +
                            "\nFurthermore, this application can also access and import a text files that contains" +
                            " the available currencies, conversion factors, \nand currency symbol that will change " +
                            "the list of supported currencies and the current conversion rates.\nLastly, there is a " +
                            "reset button that clears all records of the currency conversion count, result value " +
                            "inputted in the JTextField. \n\nAuthor: Binaya Thapa Magar " +
                            "\n© 2020 Binaya Thapa Magar All Rights Reserved",
                    "Currency Converter",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Private inner class LoadMenuItemListener that implements the ActionListener interface:
    private class LoadMenuItemListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            // Creating the object of the JFileChooser class:
            JFileChooser fileChooser = new JFileChooser();

            // Showing the dialog box where the user can search for files in their local computer and click on the
            // "Select file" button after they have chosen their file.
            // JFileChooser.APPROVE_OPTION = 0 = user choose a file, JFileChooser.CANCEL_OPTION 1 = user pressed cancel.
            int userOption = fileChooser.showDialog(null,"Select file");
            fileChooser.setVisible(true); // Making the dialog box visible.

            // Getting the user selected file which is of File class type and passing it to the method
            // loadConversionFile() if the user selected a file:
            if (userOption == JFileChooser.APPROVE_OPTION) {
                File fileName = fileChooser.getSelectedFile();
                loadCurrencyFile(fileName);

                // Counter for invalid data to be used in the for loop:
                int counterForInvalidData = 0;

                // Looping through the currencyComboBox to check if all of the data are invalid.
                for (int i = 0; i < currencyComboBox.getItemCount(); i++) {
                    if (currencyComboBox.getItemAt(i).contains("Invalid data")) {
                        counterForInvalidData++;
                    }
                }

                // If currencyComboBox item count is equal to counterForInvalidData then, all of the data in the
                // text file are corrupt and invalid In that case, we want to use the default currencies,
                // factors and symbols.
                if (currencyComboBox.getItemCount() == counterForInvalidData) {

                    // Message for the confirm dialog box:
                    String message = "Since none of the conversion " +
                            "data (conversion currencies, factors and symbols) " +
                            "from the text file are valid,\nDo you want to use the default conversion data " +
                            "(conversion currencies, factors and symbols)?";

                    // Showing a dialog box to the user to choose if they want a default conversion values if
                    // all of the text file data are corrupt and invalid.
                    int userChoice = JOptionPane.showConfirmDialog(null, message,
                            "NO VALID DATA", JOptionPane.YES_NO_OPTION);

                    // If user chose "YES" option, then we want to load the default conversion data:
                    if (userChoice == JOptionPane.YES_OPTION) {
                        currencyComboBox.removeAllItems();
                        for(String currency : startingCurrencies){
                            currencyComboBox.addItem(currency);
                        }
                        usingCurrencyFromFile = false;
                    }else{
                        // Else, we want to use the invalid data for conversion.
                        usingCurrencyFromFile = true;
                    }
                }else {
                    usingCurrencyFromFile = true; // Assigning new value to usingCurrencyFromFile
                }
                // Clearing the TextField and result when upload data from file;
                userInputTextField.setText("");
                conversionResult.setText("---");
            }
        }
    }

}